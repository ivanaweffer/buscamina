from jugador import Jugador
from juego import Juego
from menu import Menu

def main():
    """
    Función principal que inicia el juego Buscaminas.
    """
    print("Bienvenido a Buscaminas")
    nombre = input("Ingrese su nombre: ")
    jugador = Jugador(nombre)
    juego = Juego(jugador)
    menu = Menu(juego)
    menu.mostrar()

if __name__ == "__main__":
    main() 