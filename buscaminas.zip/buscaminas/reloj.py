import time

class Reloj:
    """
    Clase que gestiona el tiempo de la partida.
    """
    def __init__(self):
        """
        Inicializa el reloj.
        """
        self.tiempo_inicio = 0
        self.tiempo_final = 0

    def iniciar(self):
        """
        Inicia el conteo del tiempo.
        """
        self.tiempo_inicio = time.time()

    def detener(self):
        """
        Detiene el conteo del tiempo.
        """
        self.tiempo_final = time.time()

    def obtener_duracion(self):
        """
        Retorna la duración de la partida en segundos.
        """
        return round(self.tiempo_final - self.tiempo_inicio, 2) 