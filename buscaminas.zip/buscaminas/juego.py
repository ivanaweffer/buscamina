from jugador import Jugador
from tablero import Tablero
from reloj import Reloj
from config import ArchivoConfiguracion

class Juego:
    """
    Clase principal que gestiona la lógica del juego Buscaminas.
    """
    def __init__(self, jugador):
        """
        Inicializa el juego con el jugador y la configuración elegida.
        """
        self.jugador = jugador
        dificultades = ["easy", "medium", "hard", "impossible"]
        print("Dificultad disponible: easy, medium, hard, impossible")
        dificultad = ""
        while dificultad not in dificultades:
            dificultad = input("Seleccione dificultad: ").strip().lower()
        self.config = ArchivoConfiguracion()
        config = self.config.leer_configuracion(dificultad)
        if config is None:
            print("No se pudo cargar la configuración. Saliendo...")
            exit()
        self.tablero = Tablero(config['filas'], config['columnas'], config['minas'])
        self.reloj = Reloj()
        self.estado = 'no iniciado'

    def inicio(self):
        """
        Inicia la partida y gestiona el ciclo principal del juego.
        """
        self.estado = 'en curso'
        self.reloj.iniciar()
        while self.estado == 'en curso':
            self.tablero.mostrar()
            accion, x, y, tipo = self.jugador.realizar_entrada()
            if accion == 'revelar':
                resultado = self.tablero.revelar_casilla(x, y)
                if resultado == 'mina':
                    self.tablero.mostrar()
                    print("\n¡BOOM! Has perdido.")
                    self.terminar(victoria=False)
                    break
                elif self.verificar_victoria():
                    self.tablero.mostrar()
                    print("\n¡Felicidades! Has ganado.")
                    self.terminar(victoria=True)
                    break
            elif accion == 'marcar':
                self.tablero.marcar_casilla(x, y, tipo)

    def terminar(self, victoria):
        """
        Termina la partida, detiene el reloj y guarda el record si corresponde.
        """
        self.estado = 'terminado'
        self.reloj.detener()
        duracion = self.reloj.obtener_duracion()
        if victoria:
            print(f"Tiempo: {duracion}s")
            tamano = f"{self.tablero.filas}x{self.tablero.columnas}"
            self.config.guardar_record(self.jugador.nombre, duracion, tamano)

    def verificar_victoria(self):
        """
        Verifica si el jugador ha ganado la partida.
        """
        for fila in self.tablero.grid:
            for casilla in fila:
                if not casilla.revelado and not casilla.tiene_mina:
                    return False
        return True 