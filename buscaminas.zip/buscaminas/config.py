import os
import json
import requests
from typing import Optional

ARCHIVO_CONFIG = "configuracion_buscaminas.json"
API_BASE_PATH = "https://raw.githubusercontent.com/Algoritmos-y-Programacion/api-proyecto/refs/heads/main"
CONFIG_URL = f"{API_BASE_PATH}/config.json"
LEADERBOARD_URL = f"{API_BASE_PATH}/leaderboard.json"

class ArchivoConfiguracion:
    """
    Clase para gestionar la configuración y los records del juego.
    """
    def leer_configuracion(self, dificultad='medium'):
        """
        Lee la configuración desde archivo local o desde la API si no existe el archivo.
        """
        if os.path.exists(ARCHIVO_CONFIG):
            with open(ARCHIVO_CONFIG, "r") as f:
                return json.load(f)
        else:
            return API().consultar_configuracion(dificultad)

    def guardar_record(self, nombre, tiempo, tamano):
        """
        Guarda un nuevo record en el archivo local.
        """
        records = self.leer_records()
        records.append({"nombre": nombre, "tiempo": tiempo, "tamano": tamano})
        records = sorted(records, key=lambda r: r["tiempo"])[:3]
        with open(ARCHIVO_CONFIG, "w") as f:
            json.dump({"records": records}, f)

    def leer_records(self):
        """
        Lee los records desde el archivo local o desde la API si no existe el archivo.
        """
        if os.path.exists(ARCHIVO_CONFIG):
            with open(ARCHIVO_CONFIG, "r") as f:
                datos = json.load(f)
                return datos.get("records", [])
        else:
            return API().consultar_records()

class API:
    """
    Clase para interactuar con la API de configuración y records en GitHub.
    """
    def consultar_configuracion(self, dificultad='medium'):
        """
        Consulta la configuración del juego desde la API.
        """
        try:
            r = requests.get(CONFIG_URL)
            if r.status_code == 200:
                config = r.json()['global']
                filas, columnas = config['board_size']
                dificultades = ["easy", "medium", "hard", "impossible"]
                if dificultad not in dificultades:
                    dificultad = "medium"
                porcentaje = config['quantity_of_mines'][dificultad]
                minas = int(filas * columnas * porcentaje)
                return {'filas': filas, 'columnas': columnas, 'minas': minas}
            else:
                print("Error consultando configuración en la API.")
                return None
        except Exception as e:
            print(f"Error consultando API: {e}")
            return None

    def consultar_records(self):
        """
        Consulta los records desde la API.
        """
        try:
            r = requests.get(LEADERBOARD_URL)
            if r.status_code == 200:
                data = r.json()
                records = []
                for item in data:
                    nombre = f"{item['first_name']} {item['last_name']}"
                    tiempo = round(float(item['time']) * 60)  # minutos a segundos
                    records.append({"nombre": nombre, "tiempo": tiempo, "tamano": "8x8"})
                return records
            else:
                print("Error consultando records en la API.")
                return []
        except Exception as e:
            print(f"Error consultando API: {e}")
            return [] 