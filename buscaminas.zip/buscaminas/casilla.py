import abc

class Casilla(abc.ABC):
    def __init__(self):
        self.tiene_mina = False
        self.minas_alrededor = 0
        self.revelado = False
        self.marca = None

    @abc.abstractmethod
    def revelar(self):
        pass

    def marcar(self, tipo):
        if not self.revelado:
            self.marca = tipo

class CasillaConMina(Casilla):
    def __init__(self):
        super().__init__()
        self.tiene_mina = True

    def revelar(self):
        self.revelado = True
        return 'mina'

class CasillaSinMina(Casilla):
    def __init__(self):
        super().__init__()

    def revelar(self):
        self.revelado = True
        return self.minas_alrededor 