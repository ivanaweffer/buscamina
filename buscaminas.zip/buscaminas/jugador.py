class Jugador:
    """
    Representa a un jugador del Buscaminas.
    """
    def __init__(self, nombre):
        """
        Inicializa el jugador con su nombre.
        """
        self.nombre = nombre

    def realizar_entrada(self):
        """
        Solicita al jugador la acción a realizar y la posición en el tablero.
        """
        accion = ""
        while accion not in ["revelar", "marcar"]:
            accion = input("¿Qué deseas hacer? (revelar/marcar): ").strip().lower()
        while True:
            try:
                x = int(input("Fila: "))
                y = int(input("Columna: "))
                break
            except ValueError:
                print("Por favor, ingresa SOLO números para fila y columna.")
        tipo = None
        if accion == "marcar":
            tipo = input("Tipo de marca (bandera/interrogante): ").strip().lower()
        return accion, x, y, tipo 