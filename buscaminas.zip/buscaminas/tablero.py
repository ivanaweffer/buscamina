from casilla import CasillaConMina, CasillaSinMina

class Tablero:
    """
    Representa el tablero del juego Buscaminas.
    """
    def __init__(self, filas, columnas, minas):
        """
        Inicializa el tablero con el número de filas, columnas y minas.
        """
        self.filas = filas
        self.columnas = columnas
        self.minas = minas
        self.grid = [[None for _ in range(columnas)] for _ in range(filas)]
        self.inicializar()

    def inicializar(self):
        """
        Coloca las minas y calcula las minas alrededor de cada casilla.
        """
        import random
        posiciones = [(i, j) for i in range(self.filas) for j in range(self.columnas)]
        minas_colocadas = random.sample(posiciones, self.minas)
        for i, j in minas_colocadas:
            self.grid[i][j] = CasillaConMina()
        for i in range(self.filas):
            for j in range(self.columnas):
                if not self.grid[i][j]:
                    self.grid[i][j] = CasillaSinMina()
        for i in range(self.filas):
            for j in range(self.columnas):
                if isinstance(self.grid[i][j], CasillaSinMina):
                    self.grid[i][j].minas_alrededor = self.contar_minas_alrededor(i, j)

    def mostrar(self):
        """
        Muestra el tablero en consola.
        """
        print("   ", end="")
        for j in range(self.columnas):
            print(f"{j:2}", end=" ")
        print()
        for i in range(self.filas):
            print(f"{i:2}", end=" ")
            for j in range(self.columnas):
                casilla = self.grid[i][j]
                if casilla.revelado:
                    if hasattr(casilla, 'tiene_mina') and casilla.tiene_mina:
                        print("💣 ", end=" ")
                    else:
                        print(f" {casilla.minas_alrededor} ", end=" ")
                else:
                    if casilla.marca == 'bandera':
                        print("🚩", end=" ")
                    elif casilla.marca == 'interrogante':
                        print("?  ", end=" ")
                    else:
                        print("■  ", end=" ")
            print()

    def revelar_casilla(self, x, y):
        """
        Revela la casilla en la posición (x, y). Si no hay minas alrededor, revela en cascada.
        """
        if self.grid[x][y].revelado:
            return
        resultado = self.grid[x][y].revelar()
        if resultado == 0:
            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < self.filas and 0 <= ny < self.columnas:
                        if not self.grid[nx][ny].revelado:
                            self.revelar_casilla(nx, ny)
        return resultado

    def marcar_casilla(self, x, y, tipo):
        """
        Marca la casilla en la posición (x, y) con el tipo especificado.
        """
        self.grid[x][y].marcar(tipo)

    def contar_minas_alrededor(self, x, y):
        """
        Cuenta el número de minas alrededor de la casilla en (x, y).
        """
        contador = 0
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                nx, ny = x + dx, y + dy
                if 0 <= nx < self.filas and 0 <= ny < self.columnas:
                    if (dx != 0 or dy != 0) and self.grid[nx][ny].tiene_mina:
                        contador += 1
        return contador 