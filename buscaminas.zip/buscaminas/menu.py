class Menu:
    """
    Clase que representa el menú principal del juego.
    """
    def __init__(self, juego):
        """
        Inicializa el menú con la instancia del juego.
        """
        self.juego = juego

    def mostrar(self):
        """
        Muestra el menú principal y gestiona la selección del usuario.
        """
        while True:
            print("\n--- BUSCAMINAS ---")
            print("1. Iniciar partida")
            print("2. Mostrar records")
            print("3. Salir")
            op = input("Seleccione una opción: ").strip()
            if op == '1':
                self.iniciar_partida()
            elif op == '2':
                self.mostrar_records()
            elif op == '3':
                self.salir()
            else:
                print("Opción inválida.")

    def iniciar_partida(self):
        """
        Inicia una nueva partida.
        """
        self.juego.inicio()

    def mostrar_records(self):
        """
        Muestra los mejores tiempos guardados.
        """
        print("--- MEJORES TIEMPOS ---")
        records = self.juego.config.leer_records()
        for idx, record in enumerate(records):
            print(f"{idx+1}. {record['nombre']} - {record['tiempo']}s - Tablero: {record['tamano']}")

    def salir(self):
        """
        Sale del juego.
        """
        print("Saliendo del juego...")
        exit() 